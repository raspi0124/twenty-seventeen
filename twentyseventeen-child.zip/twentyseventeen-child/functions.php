<?php
/* functions.phpの内容を書く */

// エディターでもサイト上で見たときの外観と同じにする。
add_editor_style("../twentyseventeen/style.css");